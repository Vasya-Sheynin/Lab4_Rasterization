#ifndef MYDIALOG_H
#define MYDIALOG_H

#include <QDialog>
#include <QtWidgets>

namespace Ui {
class MyDialog;
}

class MyDialog : public QDialog
{
    Q_OBJECT

public:
    explicit MyDialog(QWidget *parent = nullptr);
    ~MyDialog();
    double getX();
    double getY();
    double getR();

private:
    Ui::MyDialog *ui;
    QLineEdit *lineEdit1;
    QLineEdit *lineEdit2;
    QLineEdit *lineEdit3;
};

#endif // MYDIALOG_H
