
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtWidgets>
#include <QtCharts>
#include <QDateTime>
#include "mydialog.h"
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow

{
    Q_OBJECT

public:
    enum RasterType { POINTS = 0, ITERATION, DDA, BREZ, BREZCIRCLE };
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    QPointF A;
    QPointF B;
    QPointF Center;
    double R;
    QScatterSeries *series;
    QChart *chart;
    RasterType type;
    double timeStart;
    double timeEnd;
    QLabel* plotTimeLbl;
    QCustomPlot* plot;

    void drawPlot();
    void drawMainPoints();
};

#endif // MAINWINDOW_H
