
#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    setWindowTitle("Raster application");

    plot = new QCustomPlot(this);
    QVBoxLayout* vbox = new QVBoxLayout();
    QGridLayout* gridLayout = new QGridLayout;
    QLabel* lbl = new QLabel("<center>Select rasterization algorithm</center>");
    QRadioButton* iterBtn = new QRadioButton("Iterative");
    QRadioButton* DDABtn = new QRadioButton("DDA");
    QRadioButton* brezBtn = new QRadioButton("Bresenham");
    QRadioButton* brezCircleBtn = new QRadioButton("Bresenham(Cricle)");
    QLabel* pointsLbl = new QLabel("Enter points A and B");
    QLabel* xaLbl = new QLabel("Xa");
    QLabel* yaLbl = new QLabel("Ya");
    QLabel* xbLbl = new QLabel("Xb");
    QLabel* ybLbl = new QLabel("Yb");
    QLabel *plotTimeTextLbl = new QLabel("<center> Rasterization time </center>");
    plotTimeLbl = new QLabel();
    QLineEdit* x0Line = new QLineEdit("0");
    QLineEdit* y0Line = new QLineEdit("0");
    QLineEdit* x1Line = new QLineEdit("0");
    QLineEdit* y1Line = new QLineEdit("0");
    QButtonGroup *buttonGroupSelect = new QButtonGroup;

    buttonGroupSelect->addButton(iterBtn);
    buttonGroupSelect->addButton(DDABtn);
    buttonGroupSelect->addButton(brezBtn);
    buttonGroupSelect->addButton(brezCircleBtn);

    QRegExp rx("^-?(?:\\d{1,5}(?:\\.\\d+)?|100000(?:\\.0+)?)$");
    QValidator* validator = new QRegExpValidator(rx);

    x0Line->setValidator(validator);
    x1Line->setValidator(validator);
    y0Line->setValidator(validator);
    y1Line->setValidator(validator);

    gridLayout->addWidget(lbl, 0, 0, 2, 1);
    gridLayout->addWidget(iterBtn, 0, 1);
    gridLayout->addWidget(DDABtn, 1, 1);
    gridLayout->addWidget(brezBtn, 0, 2);
    gridLayout->addWidget(brezCircleBtn, 1, 2);
    gridLayout->addWidget(pointsLbl, 0, 3, 2, 1);
    gridLayout->addWidget(xaLbl, 0, 4);
    gridLayout->addWidget(yaLbl, 1, 4);
    gridLayout->addWidget(x0Line, 0, 5);
    gridLayout->addWidget(y0Line, 1, 5);
    gridLayout->addWidget(xbLbl, 0, 6);
    gridLayout->addWidget(ybLbl, 1, 6);
    gridLayout->addWidget(x1Line, 0, 7);
    gridLayout->addWidget(y1Line, 1, 7);
    gridLayout->addWidget(plotTimeTextLbl, 0, 8);
    gridLayout->addWidget(plotTimeLbl, 1, 8);

    lbl->setWordWrap(true);

    A = QPointF(0, 0);
    B = QPointF(0, 0);
    type = MainWindow::RasterType::POINTS;

    vbox->addWidget(plot);
    vbox->addLayout(gridLayout);

    centralWidget()->setLayout(vbox);


    connect(x0Line, &QLineEdit::editingFinished, this, [=](){
        A = QPointF(x0Line->text().toDouble(), A.y());
        plot->graph(1)->data()->clear();
        drawMainPoints();
        drawPlot();
    });

    connect(y0Line, &QLineEdit::editingFinished, this, [=](){
        A = QPointF(A.x(), y0Line->text().toDouble());
        plot->graph(1)->data()->clear();
        drawMainPoints();
        drawPlot();
    });

    connect(x1Line, &QLineEdit::editingFinished, this, [=](){
        B = QPointF(x1Line->text().toDouble(), B.y());
        plot->graph(1)->data()->clear();
        drawMainPoints();
        drawPlot();
    });

    connect(y1Line, &QLineEdit::editingFinished, this, [=](){
        B = QPointF(B.x(), y1Line->text().toDouble());
        plot->graph(1)->data()->clear();
        drawMainPoints();
        drawPlot();
    });

    connect(iterBtn, &QRadioButton::clicked, this, [=](){
        type = RasterType::ITERATION;
        drawPlot();
    });

    connect(DDABtn, &QRadioButton::clicked, this, [=](){
        type = RasterType::DDA;
        drawPlot();
    });

    connect(brezBtn, &QRadioButton::clicked, this, [=](){
        type = RasterType::BREZ;
        drawPlot();
    });

    connect(brezCircleBtn, &QRadioButton::clicked, this, [=](){
        MyDialog* dialog = new MyDialog;
        if (dialog->exec() == QDialog::Accepted) {
            Center = QPointF(dialog->getX(), dialog->getY());
            R = dialog->getR();
            type = RasterType::BREZCIRCLE;
            drawPlot();
        }
    });

    plot->addGraph();
    plot->addGraph();
    plot->graph(0)->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssCircle, Qt::blue, 8));
    plot->graph(1)->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssCircle, Qt::red, 12));
    plot->setInteraction(QCP::iRangeZoom, true);
    plot->setInteraction(QCP::iRangeDrag, true);
    plot->xAxis->setRange(-10, 10);
    plot->yAxis->setRange(-10, 10);
    plot->xAxis->setLabel("X Axis");
    plot->yAxis->setLabel("Y Axis");
    plot->graph(0)->setLineStyle(QCPGraph::lsNone);
    plot->graph(1)->setLineStyle(QCPGraph::lsNone);
    plot->replot();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::drawPlot()
{
    timeStart = QDateTime::currentMSecsSinceEpoch();
    plot->graph(0)->data()->clear();
    plot->graph(0)->addData(qRound(A.x()), qRound(A.y()));
    plot->graph(0)->addData(qRound(B.x()), qRound(B.y()));

    QVector<QPoint> rasterPoints;

    switch(type)
    {
    case RasterType::ITERATION:
    {
        drawMainPoints();

        double dx = B.x() - A.x();
        double dy = B.y() - A.y();
        double k = qAbs(dy / dx);
        double x = A.x();
        double y = A.y();

        if (qAbs(dx) >= qAbs(dy))
        {
            while (qAbs(x - B.x()) >= 1)
            {
                rasterPoints.append(QPoint(qRound(x), qRound(y)));
                dx < 0 ? x-- : x++;
                dy < 0 ? y -= k : y += k;
            }
        }
        else
        {
            k = 1 / k;
            while (qAbs(y - B.y()) >= 1)
            {
                rasterPoints.append(QPoint(qRound(x), qRound(y)));
                dy < 0 ? y-- : y++;
                dx < 0 ? x -= qAbs(k) : x += qAbs(k);
            }
        }

        break;
    }
    case RasterType::DDA:
    {
        drawMainPoints();
        double l = std::max(qAbs(qRound(B.x()) - qRound(A.x())), qAbs(qRound(B.y()) - qRound(A.y())));
        double dx = (B.x() - A.x()) / l;
        double dy = (B.y() - A.y()) / l;

        double x = A.x();
        double y = A.y();

        rasterPoints.append(QPoint(qRound(x), qRound(y)));

        int i = 0;
        while (i < l)
        {
            x += dx;
            y += dy;
            rasterPoints.append(QPoint(qRound(x), qRound(y)));
            i++;
        }

        break;
    }
    case RasterType::BREZ:
    {
        drawMainPoints();
        double x0 = A.x();
        double x1 = B.x();
        double y0 = A.y();
        double y1 = B.y();

        bool steep = qAbs(y1 - y0) > qAbs(x1 - x0);

        if (steep)
        {
            std::swap(x0, y0);
            std::swap(x1, y1);
        }

        if (x0 > x1)
        {
            std::swap(x0, x1);
            std::swap(y0, y1);
        }

        double dx = x1 - x0;
        double dy = qAbs(y1 - y0);
        double error = dx / 2;
        double yStep = (y0 < y1) ? 1 : -1;
        double y = y0;
        for (double x = x0; x <= x1; x++)
        {
            rasterPoints.append(QPoint(qRound(steep ? y : x), qRound(steep ? x : y)));
            error -= dy;
            if (error <= 0)
            {
                y += yStep;
                error += dx;
            }
        }

        break;
    }
    case RasterType::BREZCIRCLE:
    {
        plot->graph(0)->data()->clear();
        plot->graph(1)->data()->clear();
        plot->graph(1)->addData(Center.x(), Center.y());
        double xCenter = Center.x();
        double yCenter = Center.y();
        double x = 0;
        double y = R;
        double delta = 3 - 2 * y;
        while (y >= x)
        {
            rasterPoints.append(QPoint(xCenter + x, yCenter + y));
            rasterPoints.append(QPoint(xCenter + x, yCenter - y));
            rasterPoints.append(QPoint(xCenter - x, yCenter + y));
            rasterPoints.append(QPoint(xCenter - x, yCenter - y));
            rasterPoints.append(QPoint(xCenter + y, yCenter + x));
            rasterPoints.append(QPoint(xCenter + y, yCenter - x));
            rasterPoints.append(QPoint(xCenter - y, yCenter + x));
            rasterPoints.append(QPoint(xCenter - y, yCenter - x));
            delta += delta < 0 ? 4 * x + 6 : 4 * (x - y--) + 10;
            x++;
        }

        break;
    }
    default:
        rasterPoints.clear();
        plot->graph(0)->data()->clear();
        break;
    }

    for (QPoint point : rasterPoints)
    {
        plot->graph(0)->addData(point.x(), point.y());
    }

    plot->replot();
    timeEnd = QDateTime::currentMSecsSinceEpoch();
    plotTimeLbl->setText(QString::number(timeEnd - timeStart) + " msec.");
}

void MainWindow::drawMainPoints()
{
    plot->graph(1)->data()->clear();
    plot->graph(1)->addData(A.x(), A.y());
    plot->graph(1)->addData(B.x(), B.y());
}

