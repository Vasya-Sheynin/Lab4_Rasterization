#include "mydialog.h"
#include "ui_mydialog.h"

MyDialog::MyDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MyDialog)
{
    ui->setupUi(this);

    QLabel* lblR = new QLabel("<center> Radius </center>");
    QLabel* lblX = new QLabel("<center> Center X </center>");
    QLabel* lblY = new QLabel("<center> Center Y </center>");

    lineEdit1 = new QLineEdit(this);
    lineEdit2 = new QLineEdit(this);
    lineEdit3 = new QLineEdit(this);

    QGridLayout *layout = new QGridLayout(this);

    layout->addWidget(lblX, 0, 0);
    layout->addWidget(lblY, 1, 0);
    layout->addWidget(lblR, 2, 0);
    layout->addWidget(lineEdit1, 0, 1);
    layout->addWidget(lineEdit2, 1, 1);
    layout->addWidget(lineEdit3, 2, 1);

    QRegExp rx1("^-?(?:\\d{1,5}(?:\\.\\d+)?|100000(?:\\.0+)?)$");
    QValidator* validator1 = new QRegExpValidator(rx1);

    lineEdit1->setValidator(validator1);
    lineEdit2->setValidator(validator1);

    QRegExp rx2("^(?:\\d{1,5}(?:\\.\\d+)?|100000(?:\\.0+)?)$");
    QValidator* validator2 = new QRegExpValidator(rx2);

    lineEdit3->setValidator(validator2);

    setLayout(layout);
    setWindowTitle("Circle parameters");
}

MyDialog::~MyDialog()
{
    delete ui;
}

double MyDialog::getX()
{
    return lineEdit1->text().toDouble();
}

double MyDialog::getY()
{
    return lineEdit2->text().toDouble();
}

double MyDialog::getR()
{
    return lineEdit3->text().toDouble();
}

